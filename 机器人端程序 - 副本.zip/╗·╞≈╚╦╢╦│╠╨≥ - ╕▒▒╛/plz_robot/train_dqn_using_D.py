#!/usr/bin/env python
from __future__ import print_function
import tensorflow as tf
import random
import numpy as np
import pickle
import os
from tensorflow.core.protobuf import saver_pb2

GAME = 'follower'  # the name of the game being played for log files
ACTIONS = 3  # number of valid actions
GAMMA = 0.9  # decay rate of past observations
OBSERVE = 10000  # timesteps to observe before training
EXPLORE = 2000000.  # frames over which to anneal epsilon
REPLAY_MEMORY = 50000  # number of previous transitions to remember
BATCH = 32  # size of minibatch
FRAME_PER_ACTION = 1
MAX_BATCH = 2000


def weight_variable(shape, name):
    initial = tf.truncated_normal(shape, stddev=0.01)
    return tf.Variable(initial, name)


def bias_variable(shape, name):
    initial = tf.constant(0.01, shape=shape)
    return tf.Variable(initial, name)


def conv2d(x, W, stride):
    return tf.nn.conv2d(x, W, strides=[1, stride, stride, 1], padding="SAME")


def max_pool_2x2(x):
    return tf.nn.max_pool(x, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding="SAME")


def createNetwork():
    # network weights
    W_conv1 = weight_variable([8, 8, 12, 32], "W_conv1")
    b_conv1 = bias_variable([32], "b_conv1")

    W_conv2 = weight_variable([4, 4, 32, 64], "W_conv2")
    b_conv2 = bias_variable([64], "b_conv2")

    W_conv3 = weight_variable([2, 2, 64, 64], "W_conv3")
    b_conv3 = bias_variable([64], "b_conv3")

    W_fc1 = weight_variable([384, 384], "W_fc1")
    b_fc1 = bias_variable([384], "b_fc1")

    W_fc2 = weight_variable([384, ACTIONS], "W_fc2")
    b_fc2 = bias_variable([ACTIONS], "b_fc2")


    # input layer
    s = tf.placeholder("float", [None, 60, 80, 12])

    # hidden layers
    h_conv1 = tf.nn.relu(conv2d(s, W_conv1, 2) + b_conv1)
    h_pool1 = max_pool_2x2(h_conv1)

    h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2, 2) + b_conv2)
    h_pool2 = max_pool_2x2(h_conv2)

    h_conv3 = tf.nn.relu(conv2d(h_pool2, W_conv3, 1) + b_conv3)
    h_pool3 = max_pool_2x2(h_conv3)

    h_conv3_flat = tf.reshape(h_pool3, [-1, 384])

    h_fc1 = tf.nn.relu(tf.matmul(h_conv3_flat, W_fc1) + b_fc1)

    keep_prob = tf.placeholder(tf.float32)
    #keep_prob = tf.placeholder("float")
    h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

    # readout layer
    readout = tf.matmul(h_fc1_drop, W_fc2) + b_fc2
    
    return s, readout, h_fc1, keep_prob



def trainNetwork(s, readout, h_fc1,keep_prob, sess):
    # define the cost function
    a = tf.placeholder("float", [None, ACTIONS])
    y = tf.placeholder("float", [None])
    readout_action = tf.reduce_sum(tf.mul(readout, a), reduction_indices=1)
    cost = tf.reduce_mean(tf.square(y - readout_action))
    train_step = tf.train.AdamOptimizer(1e-6).minimize(cost)

    with open("average_list_D.txt", "rb") as fp:
        list_D = pickle.load(fp,encoding='latin1')
    if len(list_D) > REPLAY_MEMORY:
        # len(list_D)-REPLAY_MEMORY items need to be deleted
        del_num = len(list_D) - REPLAY_MEMORY
        del_index = random.sample(range(len(list_D)), del_num)
        for j in sorted(del_index, reverse=True):
            del list_D[j]

    saver = tf.train.Saver(write_version=saver_pb2.SaverDef.V1) 
    sess.run(tf.initialize_all_variables())
    checkpoint = tf.train.get_checkpoint_state("saved_networks")
    if checkpoint and checkpoint.model_checkpoint_path:
        saver.restore(sess, checkpoint.model_checkpoint_path)
        print("Successfully loaded:", "saved_networks/follower_dqn")
    else:
        print("Could not find old network weights")
    # only train if done observing
    # *****************train_process_start*******************/
    for i in range(MAX_BATCH):
        print("i is:", i)
        # sample a minibatch to train on
        minibatch = random.sample(list_D, BATCH)

        # get the batch variables
        s_j_batch = [d[0] for d in minibatch]
        print("s_j_batch length is:", len(s_j_batch))
        a_batch = [d[1] for d in minibatch]
        r_batch = [d[2] for d in minibatch]
        s_j1_batch = [d[3] for d in minibatch]
        print("s_j1_batch length is:", len(s_j_batch))
        print("s_j_batch[0] shape is:", s_j_batch[0].shape)

        y_batch = []
        readout_j1_batch = readout.eval(feed_dict={s: s_j1_batch,keep_prob:0.5})
        sum_max_Q=0
        for j in range(0, len(minibatch)):
            terminal = minibatch[j][4]
            # if terminal, only equals reward
            if terminal==True:
                print("terminal is True")
                y_batch.append(r_batch[j])
            else:
                # np.max(readout_j1_batch[i]):the largest Q-value among all
                # actions for the current states
                y_batch.append(r_batch[j] + GAMMA *
                               np.max(readout_j1_batch[j]))
            sum_max_Q+=np.max(readout_j1_batch[j])
        average_max_Q=sum_max_Q/float(BATCH)

       # perform gradient step
        _, c = sess.run([train_step, cost], feed_dict={
            y: y_batch,
            a: a_batch,
            s: s_j_batch,
            keep_prob:0.5})

        print("STEP is {},cost is {},average_max_Q is:{}".format(i, c,average_max_Q))
        os.system('echo -n %f, >> average_max_Q.txt' %average_max_Q)
        # *********************train_process_end**********************/

    a=saver.save(sess, 'saved_networks/follower_dqn')
    if a=='saved_networks/follower_dqn':
        print("model has been saved.")


def playGame():
    sess = tf.InteractiveSession()
    s, readout, h_fc1,keep_prob = createNetwork()
    print("s, readout, h_fc1 is:", s, readout, h_fc1)
    trainNetwork(s, readout, h_fc1,keep_prob, sess)


if __name__ == "__main__":
    playGame()
